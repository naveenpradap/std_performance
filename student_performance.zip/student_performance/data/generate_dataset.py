"""
Generates a realistic synthetic Student Performance dataset.
Features are inspired by the well-known UCI/Kaggle "Student Performance" datasets,
but generated synthetically here so there is no licensing/download dependency.
"""

import numpy as np
import pandas as pd

np.random.seed(42)

N = 1000

genders = np.random.choice(["Male", "Female"], N)
study_hours = np.round(np.random.normal(3.2, 2.2, N).clip(0, 12), 1)
attendance = np.round(np.random.normal(72, 16, N).clip(30, 100), 1)
previous_score = np.round(np.random.normal(55, 18, N).clip(0, 100), 1)
parental_education = np.random.choice(
    ["High School", "Graduate", "Post Graduate"], N, p=[0.4, 0.4, 0.2]
)
internet_access = np.random.choice(["Yes", "No"], N, p=[0.75, 0.25])
extracurricular = np.random.choice(["Yes", "No"], N, p=[0.5, 0.5])
sleep_hours = np.round(np.random.normal(7, 1.3, N).clip(4, 10), 1)
family_income = np.random.choice(["Low", "Medium", "High"], N, p=[0.3, 0.5, 0.2])

# Compute a synthetic "final score" as a weighted function of the above + noise
score = (
    0.40 * previous_score
    + 3.8 * study_hours
    + 0.22 * attendance
    + sleep_hours * 0.8
    + (parental_education == "Post Graduate") * 4
    + (parental_education == "Graduate") * 1.5
    + (internet_access == "Yes") * 2.5
    + (extracurricular == "Yes") * 1
    + (family_income == "High") * 2
    - 12  # shift down so more students fall below the pass mark
    + np.random.normal(0, 10, N)
)

score = np.round(np.clip(score, 0, 100), 1)
result = np.where(score >= 40, "Pass", "Fail")

df = pd.DataFrame({
    "gender": genders,
    "study_hours_per_day": study_hours,
    "attendance_percentage": attendance,
    "previous_score": previous_score,
    "parental_education": parental_education,
    "internet_access": internet_access,
    "extracurricular_activities": extracurricular,
    "sleep_hours": sleep_hours,
    "family_income": family_income,
    "final_score": score,
    "result": result,
})

df.to_csv("/home/claude/student_performance/data/student_data.csv", index=False)
print(df.head())
print("\nShape:", df.shape)
print("\nResult distribution:\n", df["result"].value_counts())
