"""
Student Performance Prediction System - Flask Web App
--------------------------------------------------------
Run with:  python app.py
Then open: http://127.0.0.1:5000
"""

import os
import joblib
import numpy as np
from flask import Flask, render_template, request

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_DIR = os.path.join(BASE_DIR, "model")

app = Flask(__name__)

# Load trained artifacts
model = joblib.load(os.path.join(MODEL_DIR, "student_model.pkl"))
scaler = joblib.load(os.path.join(MODEL_DIR, "scaler.pkl"))
encoders = joblib.load(os.path.join(MODEL_DIR, "encoders.pkl"))
feature_columns = joblib.load(os.path.join(MODEL_DIR, "feature_columns.pkl"))

result_encoder = encoders["result"]  # to decode 0/1 back to Fail/Pass


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/predict", methods=["POST"])
def predict():
    try:
        # Read form inputs
        gender = request.form["gender"]
        study_hours = float(request.form["study_hours_per_day"])
        attendance = float(request.form["attendance_percentage"])
        previous_score = float(request.form["previous_score"])
        parental_education = request.form["parental_education"]
        internet_access = request.form["internet_access"]
        extracurricular = request.form["extracurricular_activities"]
        sleep_hours = float(request.form["sleep_hours"])
        family_income = request.form["family_income"]

        # Build a row in the SAME order as feature_columns, encoding categoricals
        raw_input = {
            "gender": encoders["gender"].transform([gender])[0],
            "study_hours_per_day": study_hours,
            "attendance_percentage": attendance,
            "previous_score": previous_score,
            "parental_education": encoders["parental_education"].transform([parental_education])[0],
            "internet_access": encoders["internet_access"].transform([internet_access])[0],
            "extracurricular_activities": encoders["extracurricular_activities"].transform([extracurricular])[0],
            "sleep_hours": sleep_hours,
            "family_income": encoders["family_income"].transform([family_income])[0],
        }

        input_row = np.array([[raw_input[col] for col in feature_columns]])
        input_scaled = scaler.transform(input_row)

        pred = model.predict(input_scaled)[0]
        prob = model.predict_proba(input_scaled)[0]

        prediction_label = result_encoder.inverse_transform([pred])[0]
        confidence = round(max(prob) * 100, 2)

        return render_template(
            "index.html",
            prediction=prediction_label,
            confidence=confidence,
            show_result=True,
        )

    except Exception as e:
        return render_template("index.html", error=str(e), show_result=False)


if __name__ == "__main__":
    app.run(debug=True)
