# Student Performance Prediction System

An end-to-end ML project: data preprocessing → EDA → Logistic Regression
(Pass/Fail classification) → Flask web app for live predictions.

## Project structure

```
student_performance/
├── data/
│   ├── generate_dataset.py     # creates the synthetic dataset
│   └── student_data.csv        # generated dataset (1000 students)
├── model/
│   ├── train_model.py          # preprocessing + EDA + training + saving model
│   ├── student_model.pkl       # trained Logistic Regression model
│   ├── scaler.pkl              # StandardScaler
│   ├── encoders.pkl            # LabelEncoders for categorical columns
│   ├── feature_columns.pkl     # column order used at training time
│   └── eda_plots/              # saved EDA charts (PNG)
├── templates/
│   └── index.html              # web form + result page
├── static/
│   └── style.css
├── app.py                      # Flask app (run this to launch the website)
└── README.md
```

## How to run this on your Windows machine (Anaconda + Spyder)

### 1. Open Anaconda Prompt and create/activate an environment
```
conda create -n studentpred python=3.10 -y
conda activate studentpred
```

### 2. Install dependencies
```
pip install pandas numpy scikit-learn matplotlib seaborn joblib flask
```

### 3. Generate the dataset (optional — CSV is already included)
Open `data/generate_dataset.py` in Spyder and run it (F5).
This creates `data/student_data.csv`.

### 4. Train the model
Open `model/train_model.py` in Spyder and run it (F5).

This will:
- Print dataset info, missing values, and summary statistics
- Save EDA plots to `model/eda_plots/`
- Train a Logistic Regression model
- Print accuracy, confusion matrix, and classification report
- Save `student_model.pkl`, `scaler.pkl`, `encoders.pkl`, `feature_columns.pkl` into `model/`

You should see accuracy around **76%** and ROC-AUC around **0.84** — realistic
numbers for this kind of dataset (not suspiciously perfect, which is good for
a viva/demo where you may be asked to explain the results).

### 5. Run the web app
In Anaconda Prompt (not Spyder, since Spyder's console doesn't handle Flask's
dev server well):
```
cd path\to\student_performance
python app.py
```
Then open **http://127.0.0.1:5000** in your browser.

Fill the form and click **Predict outcome** to see Pass/Fail with a confidence score.

## Notes for your report / viva

- **Algorithm used**: Logistic Regression (scikit-learn), chosen because the
  target is binary (Pass/Fail).
- **Features**: gender, study hours/day, attendance %, previous exam score,
  parental education, internet access, extracurricular activities, sleep
  hours, family income.
- **Preprocessing**: Label Encoding for categorical features, Standard
  Scaling for numeric features, 80/20 train-test split with stratification.
- **Why `final_score` is dropped before training**: it was used to derive the
  `result` label, so including it would leak the answer (the model would
  just learn "score ≥ 40 → Pass", which isn't a meaningful ML task). This is
  worth mentioning if asked — it shows you understand data leakage.
- **Evaluation metrics**: accuracy, confusion matrix, precision/recall/F1,
  ROC-AUC — all printed by `train_model.py` and saved as a confusion matrix
  plot.

## Extending this project (optional)

- Add more algorithms (Decision Tree, Random Forest) and compare accuracy.
- Add a regression model to also predict the numeric `final_score`
  (you already have Linear Regression experience from your other project —
  the same `data/student_data.csv` has a `final_score` column you can use
  as a second target, just don't mix it into the Pass/Fail features).
- Replace the synthetic dataset with a real one (e.g. upload your own CSV
  with the same column names) — no code changes needed as long as column
  names match.
- Deploy the Flask app (Render, PythonAnywhere, or Railway all have free tiers).
