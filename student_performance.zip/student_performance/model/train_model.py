"""
Student Performance Prediction System
--------------------------------------
Steps:
 1. Load data
 2. EDA (basic stats + plots saved to /model/eda_plots)
 3. Preprocessing (encoding categorical vars, scaling)
 4. Train Logistic Regression (Pass/Fail classification)
 5. Evaluate model
 6. Save model + encoders + scaler with joblib for use in the Flask app

Run this file in Spyder / any Python IDE. It will create:
  - model/student_model.pkl
  - model/scaler.pkl
  - model/encoders.pkl
  - model/eda_plots/*.png
"""

import os
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")  # so it works without a display (safe for Spyder too)
import matplotlib.pyplot as plt
import seaborn as sns
import joblib

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score, confusion_matrix, classification_report, roc_auc_score
)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_PATH = os.path.join(BASE_DIR, "..", "data", "student_data.csv")
PLOTS_DIR = os.path.join(BASE_DIR, "eda_plots")
os.makedirs(PLOTS_DIR, exist_ok=True)

# -----------------------------
# 1. LOAD DATA
# -----------------------------
df = pd.read_csv(DATA_PATH)
print("Dataset shape:", df.shape)
print(df.head())
print("\nMissing values:\n", df.isnull().sum())
print("\nData types:\n", df.dtypes)

# -----------------------------
# 2. EDA
# -----------------------------
print("\nSummary statistics:\n", df.describe())

# Result distribution
plt.figure(figsize=(5, 4))
sns.countplot(data=df, x="result", palette="Set2")
plt.title("Pass vs Fail Distribution")
plt.savefig(os.path.join(PLOTS_DIR, "result_distribution.png"), bbox_inches="tight")
plt.close()

# Study hours vs Result
plt.figure(figsize=(6, 4))
sns.boxplot(data=df, x="result", y="study_hours_per_day", palette="Set3")
plt.title("Study Hours vs Result")
plt.savefig(os.path.join(PLOTS_DIR, "study_hours_vs_result.png"), bbox_inches="tight")
plt.close()

# Attendance vs Result
plt.figure(figsize=(6, 4))
sns.boxplot(data=df, x="result", y="attendance_percentage", palette="Set3")
plt.title("Attendance vs Result")
plt.savefig(os.path.join(PLOTS_DIR, "attendance_vs_result.png"), bbox_inches="tight")
plt.close()

# Correlation heatmap (numeric columns only)
plt.figure(figsize=(7, 5))
numeric_df = df.select_dtypes(include=[np.number])
sns.heatmap(numeric_df.corr(), annot=True, cmap="coolwarm", fmt=".2f")
plt.title("Correlation Heatmap")
plt.savefig(os.path.join(PLOTS_DIR, "correlation_heatmap.png"), bbox_inches="tight")
plt.close()

print(f"\nEDA plots saved to: {PLOTS_DIR}")

# -----------------------------
# 3. PREPROCESSING
# -----------------------------
data = df.copy()

# Drop final_score for classification model (result is our target;
# final_score would leak the answer directly since result was derived from it)
data = data.drop(columns=["final_score"])

categorical_cols = [
    "gender", "parental_education", "internet_access",
    "extracurricular_activities", "family_income"
]
target_col = "result"

encoders = {}
for col in categorical_cols:
    le = LabelEncoder()
    data[col] = le.fit_transform(data[col])
    encoders[col] = le

# Encode target: Pass=1, Fail=0
target_encoder = LabelEncoder()
data[target_col] = target_encoder.fit_transform(data[target_col])
encoders["result"] = target_encoder

X = data.drop(columns=[target_col])
y = data[target_col]

feature_columns = X.columns.tolist()
print("\nFeature columns used for training:", feature_columns)

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# -----------------------------
# 4. TRAIN MODEL (Logistic Regression)
# -----------------------------
model = LogisticRegression(max_iter=1000, random_state=42)
model.fit(X_train_scaled, y_train)

# -----------------------------
# 5. EVALUATE
# -----------------------------
y_pred = model.predict(X_test_scaled)
y_prob = model.predict_proba(X_test_scaled)[:, 1]

acc = accuracy_score(y_test, y_pred)
auc = roc_auc_score(y_test, y_prob)

print(f"\nAccuracy: {acc:.4f}")
print(f"ROC-AUC: {auc:.4f}")
print("\nConfusion Matrix:\n", confusion_matrix(y_test, y_pred))
print("\nClassification Report:\n", classification_report(
    y_test, y_pred, target_names=target_encoder.classes_
))

# Confusion matrix plot
plt.figure(figsize=(5, 4))
sns.heatmap(
    confusion_matrix(y_test, y_pred), annot=True, fmt="d", cmap="Blues",
    xticklabels=target_encoder.classes_, yticklabels=target_encoder.classes_
)
plt.xlabel("Predicted")
plt.ylabel("Actual")
plt.title("Confusion Matrix")
plt.savefig(os.path.join(PLOTS_DIR, "confusion_matrix.png"), bbox_inches="tight")
plt.close()

# -----------------------------
# 6. SAVE MODEL + PREPROCESSORS
# -----------------------------
joblib.dump(model, os.path.join(BASE_DIR, "student_model.pkl"))
joblib.dump(scaler, os.path.join(BASE_DIR, "scaler.pkl"))
joblib.dump(encoders, os.path.join(BASE_DIR, "encoders.pkl"))
joblib.dump(feature_columns, os.path.join(BASE_DIR, "feature_columns.pkl"))

print("\nModel, scaler, and encoders saved successfully in /model")
